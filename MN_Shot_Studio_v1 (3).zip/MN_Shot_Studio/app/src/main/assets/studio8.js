(()=>{
const $=s=>document.querySelector(s),mk=h=>{const d=document.createElement('div');d.innerHTML=h.trim();return d.firstChild};
const V=$('#video'),PV=$('.preview'),st={b:1,i:0,u:0,ls:0};
// ---- Text style (bold / italic / underline / letter spacing) for all text, preview and export
const P=CanvasRenderingContext2D.prototype,d=Object.getOwnPropertyDescriptor(P,'font');
Object.defineProperty(P,'font',{get:d.get,set(v){let s=String(v);if(!st.b)s=s.replace(/^bold /,'');if(st.i)s='italic '+s;d.set.call(this,s);if('letterSpacing' in this)this.letterSpacing=(st.ls*(this.canvas.width/(PV.clientWidth||360)))+'px'}});
const dt=P.fillText;P.fillText=function(t,x,y,w){dt.call(this,t,x,y,w);if(st.u&&(this.textAlign==='center')){const m=this.measureText(t),wd=Math.min(m.width,w||m.width),px=parseFloat(this.font.match(/(\d+(\.\d+)?)px/)?.[1]||20);this.save();this.fillRect(x-wd/2,y+px*.55,wd,Math.max(2,px/14));this.restore()}};
$('#textPanel section').append(mk(`<div class="trim-actions"><button id="tb" type="button" style="font-weight:900">B</button><button id="ti" type="button" style="font-style:italic">I</button><button id="tu" type="button" style="text-decoration:underline">U</button></div><label>Letter spacing <input id="tls" type="range" min="0" max="20" value="0"></label>`));
const apply=()=>{const els=[$('#overlay'),...(window.__stk||[]).map(o=>o.el)];els.forEach(e=>{if(!e)return;e.style.fontWeight=st.b?'700':'400';e.style.fontStyle=st.i?'italic':'normal';e.style.textDecoration=st.u?'underline':'none';e.style.letterSpacing=st.ls+'px'});[['#tb','b'],['#ti','i'],['#tu','u']].forEach(([s,k])=>$(s).style.outline=st[k]?'2px solid #19e3c1':'none')};
[['#tb','b'],['#ti','i'],['#tu','u']].forEach(([s,k])=>$(s).onclick=()=>{st[k]=st[k]?0:1;apply()});
$('#tls').oninput=e=>{st.ls=+e.target.value;apply()};apply();setInterval(apply,700);
// ---- OUT animation for stickers and text (last 0.6s)
$('#anPanel section').append(mk('<label>Out animation <select id="ao"><option value="">None</option><option value="fade">Fade out</option><option value="shrink">Shrink</option><option value="down">Slide down</option></select></label>'));
$('#ao').onchange=e=>{const s=window.__selFn&&window.__selFn();if(s)s.ot=e.target.value};
const oa=window.__anim;window.__anim=o=>{const r=oa?oa(o):{a:1,s:1,dy:0};if(!o.ot||!V.duration)return r;const k=Math.max(0,Math.min(1,(V.duration-V.currentTime)/.6));if(k>=1)return r;if(o.ot==='fade')r.a*=k;else if(o.ot==='shrink'){r.s*=k;r.a*=k}else{r.dy+=(1-k)*.12;r.a*=k}return r};
})();
