(()=>{
const $=s=>document.querySelector(s),mk=h=>{const d=document.createElement('div');d.innerHTML=h.trim();return d.firstChild},V=$('#video'),shell=$('.timeline-shell');
let pps=40,drag=0,last=0;const DUR=new Map(),TH=new Map(),AD=new Map(),key=f=>f.name+f.size+f.lastModified;
const clen=c=>{const d=DUR.get(key(c.file));return d?Math.max(.1,(c.outPoint||d)-(c.inPoint||0)):3};
const offs=()=>{let t=0;return timelineClips.map(c=>{const o=t;t+=clen(c);return o})};
const total=()=>Math.max(3,timelineClips.reduce((a,c)=>a+clen(c),0));
const pt=()=>{const c=timelineClips[selectedClip];return c?offs()[selectedClip]+Math.max(0,V.currentTime-(c.inPoint||0)):V.currentTime||0};
window.__pt=pt;window.__vis=(o,t)=>t>=(o.t0??0)&&t<=(o.t1??1e9);
window.__fin=()=>{const F=window.__F||{},t=pt();return t>=(F.t0??0)&&t<=(F.t1??1e9)};
shell.append(mk('<div id="tlph"></div>'),mk('<div id="tlz"><button id="zo" type="button">−</button><button id="zi" type="button">+</button></div>'));
const sc=mk('<div id="tlsc"><div id="tlin"><div id="rul"></div><div id="tlrows"></div></div></div>');shell.prepend(sc);
['#addClipBtn','#muteClip'].forEach(s=>{const e=$(s);if(e)shell.append(e)});
async function meta(file){const k=key(file);if(TH.has(k))return;TH.set(k,[]);const v=document.createElement('video');v.muted=true;v.preload='auto';v.src=URL.createObjectURL(file);await new Promise(r=>{v.onloadedmetadata=r;v.onerror=r;setTimeout(r,4000)});const d=v.duration||3;DUR.set(k,d);const n=Math.min(20,Math.max(2,Math.ceil(d*40/56))),a=[],c=document.createElement('canvas');c.width=56;c.height=72;for(let i=0;i<n;i++){v.currentTime=Math.min(Math.max(0,d-.05),(i+.5)*d/n);await new Promise(r=>{v.onseeked=r;setTimeout(r,700)});try{c.getContext('2d').drawImage(v,0,0,56,72);a.push(c.toDataURL('image/jpeg',.5))}catch(e){a.push('')}}TH.set(k,a);build()}
function ameta(f){const k=key(f);if(AD.has(k))return;AD.set(k,5);const a=new Audio(URL.createObjectURL(f));a.onloadedmetadata=()=>{AD.set(k,a.duration||5);build()}}
const pos=(b,it)=>{b.style.left=it.t0()*pps+'px';b.style.width=Math.max(10,(it.t1()-it.t0())*pps)+'px'};
function bar(it){const b=mk(`<div class="bar ${it.c}"><i></i><span></span><i></i></div>`);b.querySelector('span').textContent=it.l;pos(b,it);
 b.onpointerdown=e=>{const r=b.getBoundingClientRect(),x=e.clientX-r.left,m=x<18?'l':x>r.width-18?'r':'m',a0=it.t0(),a1=it.t1(),sx=e.clientX;drag=1;b.setPointerCapture(e.pointerId);
  b.onpointermove=v=>{const d=(v.clientX-sx)/pps;let n0=a0,n1=a1;if(m==='m'){n0=Math.max(0,a0+d);n1=n0+a1-a0}else if(m==='l')n0=Math.min(a1-.2,Math.max(0,a0+d));else n1=Math.max(a0+.2,a1+d);it.set(n0,n1);pos(b,it)};
  b.onpointerup=()=>{drag=0;b.onpointermove=null;V.dispatchEvent(new Event('timeupdate'))}};return b}
const row=(cls)=>mk(`<div class="trow ${cls||''}"></div>`);
function build(){if(drag)return;const T=total(),R=$('#tlrows'),keep=sc.scrollLeft;R.innerHTML='';R.style.width=T*pps+'px';
 const rul=$('#rul');rul.style.setProperty('--pps',pps+'px');rul.style.width=T*pps+'px';rul.innerHTML='';const st=pps>=60?1:pps>=30?2:5;for(let s=0;s<=T;s+=st){const l=document.createElement('span');l.style.left=s*pps+'px';l.textContent=(Math.floor(s/60)+':'+String(s%60).padStart(2,'0'));rul.append(l)}
 const vr=row('vid'),o=offs();timelineClips.forEach((c,i)=>{meta(c.file);const e=mk(`<div class="clip${i===selectedClip?' sel':''}"></div>`);e.style.left=o[i]*pps+'px';e.style.width=clen(c)*pps+'px';(TH.get(key(c.file))||[]).forEach(u=>{const d=document.createElement('div');if(u)d.style.backgroundImage=`url(${u})`;e.append(d)});e.onclick=()=>selectClip(i);vr.append(e)});R.append(vr);
 const add=(items)=>{if(!items.length)return;const r=row();items.forEach(it=>r.append(bar(it)));R.append(r)};
 add(extraAudioTracks.map(t=>{ameta(t.file);const d=AD.get(key(t.file))||5;return{c:'au',l:'♪ '+t.file.name,t0:()=>t.startAt||0,t1:()=>t.endAt>(t.startAt||0)?t.endAt:(t.startAt||0)+d,set:(a,b)=>{t.startAt=a;t.endAt=b}}}));
 add((window.__stk||[]).map(s=>({c:'tx',l:s.t,t0:()=>s.t0??0,t1:()=>s.t1??T,set:(a,b)=>{s.t0=a;s.t1=b}})));
 add(subtitleCues.slice(0,60).map(q=>({c:'sb',l:q.text||'',t0:()=>q.start,t1:()=>q.end,set:(a,b)=>{q.start=a;q.end=b}})));
 const F=window.__F;if(F&&F.cur)add([{c:'fl',l:'✦ '+(F.n||'Filter'),t0:()=>F.t0??0,t1:()=>F.t1??T,set:(a,b)=>{F.t0=a;F.t1=b;window.updateFilter&&updateFilter()}}]);
 sc.scrollLeft=keep}
// scroll <-> playback
function seekP(t){const o=offs();let i=0;for(let k=0;k<o.length;k++)if(t>=o[k])i=k;const c=timelineClips[i];if(!c)return;const tt=(c.inPoint||0)+Math.max(0,t-o[i]);if(i!==selectedClip){selectClip(i);V.addEventListener('loadedmetadata',()=>V.currentTime=tt,{once:true})}else V.currentTime=tt}
sc.addEventListener('scroll',()=>{if(Math.abs(sc.scrollLeft-last)<2||!V.paused||drag)return;seekP(sc.scrollLeft/pps)});
const sync=()=>{const t=pt();last=t*pps;sc.scrollLeft=last;(window.__stk||[]).forEach(s=>s.el.style.display=window.__vis(s,t)?'':'none');if(window.updateFilter&&window.__F&&window.__F.cur)updateFilter()};
V.addEventListener('timeupdate',()=>{if(!drag)sync()});setInterval(()=>{if(!V.paused&&!drag)sync()},80);
$('#zi').onclick=()=>{pps=Math.min(120,pps*1.4);build()};$('#zo').onclick=()=>{pps=Math.max(15,pps/1.4);build()};
const rt=window.renderTimeline;window.renderTimeline=function(){const r=rt?rt.apply(this,arguments):0;setTimeout(build,0);return r};
let sig='';setInterval(()=>{const g=timelineClips.length+'|'+selectedClip+'|'+extraAudioTracks.length+'|'+(window.__stk||[]).length+'|'+subtitleCues.length+'|'+((window.__F||{}).n||'');if(g!==sig){sig=g;build()}},500);
build();
})();
