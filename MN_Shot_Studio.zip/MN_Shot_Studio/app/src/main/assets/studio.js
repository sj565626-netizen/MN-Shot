(()=>{
const $=s=>document.querySelector(s),mk=(h)=>{const d=document.createElement('div');d.innerHTML=h.trim();return d.firstChild};
const EN=['Roboto','Arial','Georgia','Impact','Trebuchet MS','Courier New','Brush Script MT','cursive'];
const UR=['Noto Nastaliq Urdu','Jameel Noori Nastaleeq','Noto Naskh Arabic','Droid Arabic Naskh','Traditional Arabic'];
const custom=[];let cur='';
const fam=n=>n?`"${n}",sans-serif`:'';
// canvas export uses the chosen font
const d=Object.getOwnPropertyDescriptor(CanvasRenderingContext2D.prototype,'font');
Object.defineProperty(CanvasRenderingContext2D.prototype,'font',{get:d.get,set(v){d.set.call(this,window.__mnFont?String(v).replace(/sans-serif$/,window.__mnFont):v)}});
function apply(n){cur=n;window.__mnFont=fam(n);const o=$('#overlay');if(o){o.style.fontFamily=fam(n)||'';o.dir='auto'}const s=$('#fontSample');if(s)s.style.fontFamily=fam(n)||''}
// font panel
$('.tool-dock').appendChild(mk('<button type="button" data-panel="fontPanel"><span>Aa</span>Fonts</button>'));
$('.editor-panels').appendChild(mk(`<div id="fontPanel" class="tool-panel" hidden><section><h3>Fonts</h3><div id="fontSample">Hello  اردو متن</div><label>Font <select id="fontSel"></select></label><label>Import font (.ttf .otf .woff)<input id="fontFile" type="file" accept=".ttf,.otf,.woff,.woff2"></label><small>Urdu fonts depend on your phone. Import a Nastaliq font (e.g. Jameel Noori) to be sure it works.</small></section></div>`));
const sel=$('#fontSel');
function fill(){sel.innerHTML='<option value="">Default</option>'+[['English',EN],['Urdu / اردو',UR],['My fonts',custom]].map(([g,a])=>a.length?`<optgroup label="${g}">${a.map(n=>`<option>${n}</option>`).join('')}</optgroup>`:'').join('');sel.value=cur}
sel.onchange=()=>apply(sel.value);
const db=new Promise(r=>{try{const q=indexedDB.open('mnfonts',1);q.onupgradeneeded=()=>q.result.createObjectStore('f');q.onsuccess=()=>r(q.result);q.onerror=()=>r(null)}catch(e){r(null)}});
async function add(name,buf,save){const f=new FontFace(name,buf);await f.load();document.fonts.add(f);if(!custom.includes(name))custom.push(name);if(save){const h=await db;h&&h.transaction('f','readwrite').objectStore('f').put(buf,name)}}
$('#fontFile').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const n=f.name.replace(/\.[^.]+$/,'');await add(n,await f.arrayBuffer(),true);fill();sel.value=n;apply(n)}catch(x){alert('Could not load this font file.')}};
(async()=>{const h=await db;if(h){const s=h.transaction('f').objectStore('f'),k=s.getAllKeys();k.onsuccess=async()=>{for(const n of k.result){const g=h.transaction('f').objectStore('f').get(n);await new Promise(r=>{g.onsuccess=async()=>{try{await add(n,g.result,false)}catch(e){}r()}})}fill()}}fill()})();
// photo + collage screens
const app=$('.app'),home=$('#homeScreen'),edit=$('#editorScreen');
const dl=c=>c.toBlob(b=>{const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='MN_Cut_'+Date.now()+'.png';a.click()});
const load=f=>new Promise(r=>{const i=new Image();i.onload=()=>r(i);i.src=URL.createObjectURL(f)});
function screen(id,title,body){const s=mk(`<section id="${id}" class="sub" hidden><div class="row"><button class="bk">‹ Back</button><b style="align-self:center">${title}</b></div>${body}</section>`);app.appendChild(s);s.querySelector('.bk').onclick=()=>{s.hidden=true;home.hidden=false};return s}
const show=s=>{home.hidden=true;edit.hidden=true;s.hidden=false;window.scrollTo(0,0)};
// Photo
const P=screen('photoScreen','Photo editor',`<canvas id="pc" width="1080" height="1080"></canvas><label>Photo<input id="pf" type="file" accept="image/*"></label><label>Preset<select id="pp"><option value="">Original</option><option value="saturate(1.5) contrast(1.1)">Vivid</option><option value="grayscale(1)">B&amp;W</option><option value="sepia(.5) saturate(1.2)">Warm</option><option value="hue-rotate(180deg) saturate(.9)">Cool</option><option value="sepia(.8) contrast(.9)">Vintage</option></select></label><label>Brightness<input id="pb" type="range" min="50" max="150" value="100"></label><label>Contrast<input id="pcn" type="range" min="50" max="150" value="100"></label><label>Saturation<input id="ps" type="range" min="0" max="200" value="100"></label><label>Blur<input id="pbl" type="range" min="0" max="10" value="0"></label><div class="row"><button id="pr">⟳ Rotate</button><button id="pfl">⇋ Flip</button></div><label>Text<input id="pt" placeholder="Type text / اردو لکھیں"></label><label>Text position<select id="pps"><option value=".5">Center</option><option value=".12">Top</option><option value=".88">Bottom</option></select></label><label>Text size<input id="pz" type="range" min="20" max="200" value="80"></label><label>Text color<input id="pk" type="color" value="#ffffff"></label><button class="go" id="psv">Save photo (PNG)</button>`);
let img=null,rot=0,flip=1;const pc=P.querySelector('#pc'),px=pc.getContext('2d'),g=i=>P.querySelector(i);
function draw(){px.clearRect(0,0,pc.width,pc.height);px.fillStyle='#000';px.fillRect(0,0,pc.width,pc.height);if(img){const q=rot%2?[img.height,img.width]:[img.width,img.height];pc.width=Math.min(1600,q[0]);pc.height=pc.width*q[1]/q[0];px.filter=`${g('#pp').value} brightness(${g('#pb').value}%) contrast(${g('#pcn').value}%) saturate(${g('#ps').value}%) blur(${g('#pbl').value}px)`;px.save();px.translate(pc.width/2,pc.height/2);px.rotate(rot*Math.PI/2);px.scale(flip,1);const w=rot%2?pc.height:pc.width,h=rot%2?pc.width:pc.height;px.drawImage(img,-w/2,-h/2,w,h);px.restore();px.filter='none'}const t=g('#pt').value;if(t){const s=Number(g('#pz').value)*pc.width/1080;px.font=`bold ${s}px sans-serif`;px.textAlign='center';px.textBaseline='middle';const y=pc.height*g('#pps').value;px.lineWidth=s/10;px.strokeStyle='#000';px.strokeText(t,pc.width/2,y,pc.width*.9);px.fillStyle=g('#pk').value;px.fillText(t,pc.width/2,y,pc.width*.9)}}
P.querySelectorAll('input:not(#pf),select').forEach(e=>e.oninput=draw);
g('#pf').onchange=async e=>{if(e.target.files[0]){img=await load(e.target.files[0]);rot=0;flip=1;draw()}};
g('#pr').onclick=()=>{rot=(rot+1)%4;draw()};g('#pfl').onclick=()=>{flip*=-1;draw()};g('#psv').onclick=()=>dl(pc);
$('#homePhoto').onclick=()=>{show(P);draw()};
// Collage
const L={'2 side by side':[[0,0,.5,1],[.5,0,.5,1]],'2 stacked':[[0,0,1,.5],[0,.5,1,.5]],'3 (1 big + 2)':[[0,0,.6,1],[.6,0,.4,.5],[.6,.5,.4,.5]],'4 grid':[[0,0,.5,.5],[.5,0,.5,.5],[0,.5,.5,.5],[.5,.5,.5,.5]],'6 grid':[[0,0,.5,.33],[.5,0,.5,.33],[0,.33,.5,.34],[.5,.33,.5,.34],[0,.67,.5,.33],[.5,.67,.5,.33]]};
const C=screen('collageScreen','Collage',`<canvas id="cc" width="1080" height="1080"></canvas><label>Layout<select id="cl">${Object.keys(L).map(k=>`<option>${k}</option>`).join('')}</select></label><label>Photos<input id="cf" type="file" accept="image/*" multiple></label><label>Gap<input id="cg" type="range" min="0" max="40" value="8"></label><label>Background<input id="cb" type="color" value="#0c0d10"></label><button class="go" id="csv">Save collage (PNG)</button>`);
const cc=C.querySelector('#cc'),cx=cc.getContext('2d'),h=i=>C.querySelector(i);let imgs=[];
function cd(){cx.fillStyle=h('#cb').value;cx.fillRect(0,0,1080,1080);const gp=Number(h('#cg').value);L[h('#cl').value].forEach((r,i)=>{const x=r[0]*1080+gp,y=r[1]*1080+gp,w=r[2]*1080-gp*2,hh=r[3]*1080-gp*2,m=imgs[i];cx.save();cx.beginPath();cx.rect(x,y,w,hh);cx.clip();if(m){const s=Math.max(w/m.width,hh/m.height);cx.drawImage(m,x+(w-m.width*s)/2,y+(hh-m.height*s)/2,m.width*s,m.height*s)}else{cx.fillStyle='#1f222a';cx.fillRect(x,y,w,hh)}cx.restore()})}
C.querySelectorAll('input:not(#cf),select').forEach(e=>e.oninput=cd);
h('#cf').onchange=async e=>{imgs=await Promise.all([...e.target.files].map(load));cd()};h('#csv').onclick=()=>dl(cc);
$('#homeCollage').onclick=()=>{show(C);cd()};
})();
