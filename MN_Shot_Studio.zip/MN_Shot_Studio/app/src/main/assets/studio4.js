(()=>{
const $=s=>document.querySelector(s),mk=h=>{const d=document.createElement('div');d.innerHTML=h.trim();return d.firstChild};
const V=$('#video'),PV=$('.preview'),dock=$('.tool-dock'),pan=$('.editor-panels');
const tab=(id,ic,lb,body)=>{dock.appendChild(mk(`<button type="button" data-panel="${id}"><span>${ic}</span>${lb}</button>`));pan.appendChild(mk(`<div id="${id}" class="tool-panel" hidden><section>${body}</section></div>`))};
const E={hue:0,sep:0,blur:0,fade:0,warm:0,vig:0,grain:0,shake:0,glitch:0};
// ---- extra adjustments join the existing filter (preview + export)
const fs=window.filterString;window.filterString=()=>{const w=E.warm;return (fs?fs():'')+` hue-rotate(${E.hue}deg) sepia(${E.sep/100+Math.max(0,w)/200}) blur(${E.blur}px) opacity(${1-E.fade/200})`+(w<0?` hue-rotate(${w*.3}deg)`:'')};
const upd=()=>{if(window.updateFilter)updateFilter();vg.style.opacity=E.vig/100;gr.style.opacity=E.grain/100;V.style.left=V.style.top='0'};
// overlays for preview
const vg=mk('<div style="position:absolute;inset:0;pointer-events:none;z-index:3;background:radial-gradient(ellipse at center,transparent 45%,#000 120%);opacity:0"></div>');
const n=document.createElement('canvas');n.width=n.height=96;{const c=n.getContext('2d'),d=c.createImageData(96,96);for(let i=0;i<d.data.length;i+=4){const v=Math.random()*255;d.data[i]=d.data[i+1]=d.data[i+2]=v;d.data[i+3]=255}c.putImageData(d,0,0)}
const gr=mk(`<div style="position:absolute;inset:0;pointer-events:none;z-index:3;mix-blend-mode:overlay;opacity:0;background:url(${n.toDataURL()})"></div>`);
PV.append(vg,gr);
tab('fxPanel','✺','Effects',`<h3>Effects &amp; looks</h3><label>Look <select id="lk"><option value="">Choose a look…</option><option>Cinematic</option><option>Retro VHS</option><option>Dreamy</option><option>Noir</option><option>Reset</option></select></label><label>Vignette <input data-e="vig" type="range" min="0" max="100" value="0"></label><label>Film grain <input data-e="grain" type="range" min="0" max="100" value="0"></label><label>Shake <input data-e="shake" type="range" min="0" max="10" value="0"></label><label>Glitch <input data-e="glitch" type="range" min="0" max="10" value="0"></label><small>Glitch shows in exported video only.</small>`);
tab('adjPanel','☼','Adjust',`<h3>Adjust</h3><label>Warmth <input data-e="warm" type="range" min="-100" max="100" value="0"></label><label>Hue <input data-e="hue" type="range" min="-180" max="180" value="0"></label><label>Sepia <input data-e="sep" type="range" min="0" max="100" value="0"></label><label>Blur <input data-e="blur" type="range" min="0" max="10" step="0.5" value="0"></label><label>Fade <input data-e="fade" type="range" min="0" max="60" value="0"></label><small>Brightness, contrast and saturation are in the Filter tab.</small>`);
document.querySelectorAll('[data-e]').forEach(i=>i.oninput=()=>{E[i.dataset.e]=+i.value;upd()});
const LK={Cinematic:{vig:55,grain:20,warm:25,fade:10},'Retro VHS':{grain:45,glitch:5,hue:-10,sep:25,vig:30},Dreamy:{blur:1.5,warm:30,fade:15,vig:20},Noir:{vig:70,grain:35,sep:0,fade:0},Reset:{vig:0,grain:0,shake:0,glitch:0,hue:0,sep:0,blur:0,fade:0,warm:0}};
$('#lk').onchange=e=>{const l=LK[e.target.value];if(!l)return;Object.keys(E).forEach(k=>E[k]=l[k]||0);document.querySelectorAll('[data-e]').forEach(i=>i.value=E[i.dataset.e]);upd();const fp=$('#filterPreset');if(e.target.value==='Noir'){fp.value='mono'}else if(e.target.value==='Reset'){fp.value='none'}fp.dispatchEvent(new Event('change'));upd()};
// shake in preview + export; glitch/vignette/grain in export
const sh=()=>E.shake?[Math.sin(V.currentTime*47)*E.shake*.3,Math.cos(V.currentTime*61)*E.shake*.3]:[0,0];
V.addEventListener('timeupdate',()=>{const [x,y]=sh();if(E.shake)PV.style.setProperty('--sh',`${x}px ${y}px`);V.style.marginLeft=x+'px';V.style.marginTop=y+'px'});
const di=CanvasRenderingContext2D.prototype.drawImage;
CanvasRenderingContext2D.prototype.drawImage=function(im,...a){
 if(im===V&&a.length===4&&E.shake){const [x,y]=sh(),k=a[2]/(PV.clientWidth||1);a=[a[0]+x*k,a[1]+y*k,a[2],a[3]]}
 const r=di.call(this,im,...a);
 if(im===V&&a.length===4&&E.glitch&&Math.floor(V.currentTime*8)%4===0){const [x,y,w,h]=a,by=y+((V.currentTime*997)%1)*h*.8,bh=h*.08,o=E.glitch*w*.012;this.save();this.globalAlpha=.9;di.call(this,V,0,(by-y)/h*V.videoHeight,V.videoWidth,V.videoHeight*.08,x+o,by,w,bh);this.restore()}
 return r};
const od=window.drawSubtitle;window.drawSubtitle=function(ctx,cv){if(od)od.apply(this,arguments);
 if(E.vig){const g=ctx.createRadialGradient(cv.width/2,cv.height/2,Math.min(cv.width,cv.height)*.3,cv.width/2,cv.height/2,Math.max(cv.width,cv.height)*.75);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,`rgba(0,0,0,${E.vig/100})`);ctx.fillStyle=g;ctx.fillRect(0,0,cv.width,cv.height)}
 if(E.grain){ctx.save();ctx.globalAlpha=E.grain/260;for(let i=0;i<260;i++){ctx.fillStyle=Math.random()<.5?'#fff':'#000';ctx.fillRect(Math.random()*cv.width,Math.random()*cv.height,2,2)}ctx.restore()}};
// ---- Text animations for stickers
tab('anPanel','Ⓐ','Text FX',`<h3>Text animation</h3><label>Animation <select id="an"><option value="">None</option><option value="fade">Fade in</option><option value="pop">Pop</option><option value="slide">Slide up</option><option value="bounce">Bounce</option><option value="pulse">Pulse</option></select></label><small>Select a sticker or text in the Stickers tab first, then choose. Fade, pop and slide play at the start of the clip; bounce and pulse loop.</small>`);
window.__anim=o=>{const t=V.currentTime||0,k=Math.min(1,t/.6),e=1-Math.pow(1-k,3);switch(o.an){case'fade':return{a:e,s:1,dy:0};case'pop':return{a:e,s:.4+.6*e+(k<1?Math.sin(k*3.14)*.15:0),dy:0};case'slide':return{a:e,s:1,dy:(1-e)*.12};case'bounce':return{a:1,s:1,dy:-Math.abs(Math.sin(t*5))*.04};case'pulse':return{a:1,s:1+Math.sin(t*6)*.08,dy:0};default:return{a:1,s:1,dy:0}}};
$('#an').onchange=e=>{const s=window.__selFn&&window.__selFn();if(s)s.an=e.target.value};
V.addEventListener('timeupdate',()=>(window.__stk||[]).forEach(o=>{if(!o.an){o.el.style.opacity=1;o.el.style.transform='translate(-50%,-50%)';return}const A=window.__anim(o);o.el.style.opacity=A.a;o.el.style.transform=`translate(-50%,calc(-50% + ${A.dy*PV.clientHeight}px)) scale(${A.s})`}));
})();
