(()=>{
const $=s=>document.querySelector(s),mk=h=>{const d=document.createElement('div');d.innerHTML=h.trim();return d.firstChild};
const V=$('#video'),PV=$('.preview');
const openTab=id=>{const b=document.querySelector(`.tool-dock [data-panel="${id}"]`);b&&b.click()};
// ---- Audio screen row (Music+, Add audio+, Record+, Extract)
const ap=$('#audioPanel section'),row=mk(`<div class="aud"><button id="a1" type="button" style="color:#b57edc"><i>♪</i>Music+</button><button id="a2" type="button" style="color:#e05fa0"><i>✸</i>Add audio+</button><button id="a3" type="button" style="color:#e55b5b"><i>●</i>Record+</button><button id="a4" type="button" style="color:#e0884a"><i>⇥</i>Extract</button></div>`);
ap.prepend(row);
$('#a1').onclick=()=>$('#musicFile').click();$('#a2').onclick=()=>$('#extraAudioFiles').click();
$('#a3').onclick=()=>openTab('vcPanel');
$('#a4').onclick=()=>{const f=($('#multiFiles').files[0])||($('#file').files[0]);if(!f){alert('Add a video first.');return}const dt=new DataTransfer();dt.items.add(f);const i=$('#extraAudioFiles');i.files=dt.files;i.dispatchEvent(new Event('change',{bubbles:true}))};
// ---- Font list, each name shown in its own font
const sel=$('#fontSel'),fp=$('#fontPanel section');
if(sel){const fl=mk('<div class="fl"></div>');sel.closest('label').style.display='none';fp.append(fl,mk('<button type="button" id="fi" style="width:100%;margin-top:8px;padding:10px">⬇ Import font</button>'));
 $('#fi').onclick=()=>$('#fontFile').click();$('#fontFile').closest('label').style.display='none';
 const build=()=>{fl.innerHTML='';[...sel.options].forEach(o=>{const b=mk('<button type="button"></button>');b.textContent=o.value?o.value:'Default';if(o.value)b.style.fontFamily=`"${o.value}",sans-serif`;if(sel.value===o.value)b.classList.add('on');b.onclick=()=>{sel.value=o.value;sel.dispatchEvent(new Event('change'));build()};fl.append(b)})};
 new MutationObserver(build).observe(sel,{childList:true,subtree:true});build()}
// ---- Doodle (draw with finger, exported)
const dc=mk('<canvas id="doodle"></canvas>');PV.append(dc);let dr=0,on=0,lx,ly;
const fit=()=>{if(dc.width!==PV.clientWidth||dc.height!==PV.clientHeight){const t=dc.toDataURL(),im=new Image();dc.width=PV.clientWidth;dc.height=PV.clientHeight;im.onload=()=>dc.getContext('2d').drawImage(im,0,0,dc.width,dc.height);im.src=t}};
$('#stkPanel section').append(mk('<div class="trim-actions"><button id="dd" type="button">✎ Doodle: off</button><button id="dx" type="button">Clear doodle</button></div>'));
$('#dd').onclick=e=>{on=!on;fit();dc.style.pointerEvents=on?'auto':'none';e.target.textContent='✎ Doodle: '+(on?'on':'off')};
$('#dx').onclick=()=>dc.getContext('2d').clearRect(0,0,dc.width,dc.height);
dc.onpointerdown=e=>{dr=1;const r=dc.getBoundingClientRect();lx=e.clientX-r.left;ly=e.clientY-r.top;dc.setPointerCapture(e.pointerId)};
dc.onpointermove=e=>{if(!dr)return;const r=dc.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top,c=dc.getContext('2d');c.strokeStyle=$('#sc').value;c.lineWidth=6;c.lineCap='round';c.beginPath();c.moveTo(lx,ly);c.lineTo(x,y);c.stroke();lx=x;ly=y};
dc.onpointerup=()=>dr=0;
const od=window.drawSubtitle;window.drawSubtitle=function(ctx,cv){if(od)od.apply(this,arguments);if(dc.width&&dc.height)ctx.drawImage(dc,0,0,cv.width,cv.height)};
// ---- Mask (circle / ellipse / rounded) in preview and export
$('#adjPanel section').append(mk('<label>Mask <select id="mk2"><option value="">None</option><option value="circle">Circle</option><option value="ellipse">Oval</option><option value="round">Rounded</option></select></label>'));
let M='';const CP={circle:'circle(closest-side at 50% 50%)',ellipse:'ellipse(50% 40% at 50% 50%)',round:'inset(0 round 12%)'};
$('#mk2').onchange=e=>{M=e.target.value;V.style.clipPath=CP[M]||''};
const di=CanvasRenderingContext2D.prototype.drawImage;
CanvasRenderingContext2D.prototype.drawImage=function(im,...a){
 if(im===V&&a.length===4&&M){const [x,y,w,h]=a;this.save();this.beginPath();
  if(M==='circle')this.ellipse(x+w/2,y+h/2,Math.min(w,h)/2,Math.min(w,h)/2,0,0,7);
  else if(M==='ellipse')this.ellipse(x+w/2,y+h/2,w/2,h*.4,0,0,7);
  else if(this.roundRect)this.roundRect(x,y,w,h,Math.min(w,h)*.12);else this.rect(x,y,w,h);
  this.clip();const r=di.call(this,im,...a);this.restore();return r}
 return di.call(this,im,...a)};
})();
