(()=>{
const $=s=>document.querySelector(s),mk=h=>{const d=document.createElement('div');d.innerHTML=h.trim();return d.firstChild};
const V=$('#video'),PV=$('.preview'),dock=$('.tool-dock'),pan=$('.editor-panels');
const tab=(id,ic,lb,body)=>{dock.appendChild(mk(`<button type="button" data-panel="${id}"><span>${ic}</span>${lb}</button>`));pan.appendChild(mk(`<div id="${id}" class="tool-panel" hidden><section>${body}</section></div>`))};
const S={z:1,x:0,y:0,kb:1,ck:0,ct:60,cc:[0,255,0]};
const prog=()=>V.duration?V.currentTime/V.duration:0,kz=()=>S.z*(1+(S.kb-1)*prog());
function xf(){const [r,f]=window.__rf||[0,1];V.style.transform=`translate(${S.x}%,${S.y}%) rotate(${r*90}deg) scaleX(${f}) scale(${kz()})`}
document.addEventListener('mnxf',xf);V.addEventListener('timeupdate',xf);
// canvas draw hook: rotate / flip / zoom / pan / Ken Burns / chroma key now apply in export too
const di=CanvasRenderingContext2D.prototype.drawImage,tc=document.createElement('canvas');
CanvasRenderingContext2D.prototype.drawImage=function(im,...a){
 if(im!==V||a.length!==4)return di.call(this,im,...a);
 const [x,y,w,h]=a,[r,f]=window.__rf||[0,1],k=kz();
 if(!r&&f===1&&k===1&&!S.x&&!S.y&&!S.ck)return di.call(this,im,x,y,w,h);
 this.save();if(S.ck){this.fillStyle=$('#bg')?.value||'#000';this.fillRect(x,y,w,h)}
 this.translate(x+w/2+S.x/100*w,y+h/2+S.y/100*h);this.rotate(r*Math.PI/2);this.scale(f*k,k);
 if(S.ck){tc.width=Math.min(640,w);tc.height=Math.round(tc.width*h/w);const c=tc.getContext('2d');di.call(c,V,0,0,tc.width,tc.height);const d=c.getImageData(0,0,tc.width,tc.height),p=d.data,t=S.ct*4.4;for(let i=0;i<p.length;i+=4){const q=Math.abs(p[i]-S.cc[0])+Math.abs(p[i+1]-S.cc[1])+Math.abs(p[i+2]-S.cc[2]);if(q<t)p[i+3]=0}c.putImageData(d,0,0);di.call(this,tc,-w/2,-h/2,w,h)}
 else di.call(this,im,-w/2,-h/2,w,h);
 this.restore()};
// preview canvas for chroma key
const kc=mk('<canvas style="position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:2"></canvas>');PV.appendChild(kc);kc.hidden=true;
(function loop(){if(S.ck&&V.videoWidth){kc.width=PV.clientWidth;kc.height=PV.clientHeight;const c=kc.getContext('2d');c.fillStyle=$('#bg')?.value||'#000';c.fillRect(0,0,kc.width,kc.height);const t=V.style.transform;V.style.transform='none';c.drawImage(V,0,0,kc.width,kc.height);V.style.transform=t}requestAnimationFrame(loop)})();
// ---- Magic tab
tab('magPanel','✨','Magic',`<h3>Zoom, motion, reverse, chroma</h3><label>Zoom <input id="mz" type="range" min="1" max="3" step="0.05" value="1"></label><label>Move left/right <input id="mx" type="range" min="-50" max="50" value="0"></label><label>Move up/down <input id="my" type="range" min="-50" max="50" value="0"></label><label>Slow zoom to (keyframe) <input id="mk" type="range" min="1" max="2" step="0.05" value="1"></label><div class="trim-actions"><button id="mr" type="button">⏪ Reverse play</button></div><label>Chroma key (remove color) <input id="ck" type="checkbox"></label><label>Key color <input id="cc" type="color" value="#00ff00"></label><label>Strength <input id="ct" type="range" min="5" max="150" value="60"></label><small>Keyed area shows the Format tab background color. Reverse is preview only.</small>`);
const bind=(id,fn)=>$(id).oninput=e=>{fn(e.target);xf()};
bind('#mz',e=>S.z=+e.value);bind('#mx',e=>S.x=+e.value);bind('#my',e=>S.y=+e.value);bind('#mk',e=>S.kb=+e.value);bind('#ct',e=>S.ct=+e.value);
$('#cc').oninput=e=>{const h=e.target.value;S.cc=[1,3,5].map(i=>parseInt(h.substr(i,2),16))};
$('#ck').onchange=e=>{S.ck=e.target.checked?1:0;kc.hidden=!S.ck;V.style.opacity=S.ck?0:1};
let rev=0;$('#mr').onclick=e=>{rev=!rev;e.target.textContent=rev?'⏹ Stop reverse':'⏪ Reverse play';if(!rev)return;V.pause();let t0=performance.now();(function st(n){if(!rev)return;const d=(n-t0)/1000;t0=n;V.currentTime=Math.max(0,V.currentTime-d*(V.playbackRate||1));if(V.currentTime<=0){rev=0;e.target.textContent='⏪ Reverse play';return}requestAnimationFrame(st)})(t0)};
// ---- PIP overlay
tab('pipPanel','▣','PIP',`<h3>Picture in picture</h3><label>Add photo or video <input id="pf2" type="file" accept="image/*,video/*"></label><label>Size <input id="pz2" type="range" min="10" max="90" value="35"></label><div class="trim-actions"><button id="pd" type="button">🗑 Remove</button></div><small>Drag it on the preview. Included in export.</small>`);
let pip=null,pw=.35,px=.7,py=.25;
const pl=()=>{if(!pip)return;pip.style.cssText=`position:absolute;z-index:5;touch-action:none;left:${px*100}%;top:${py*100}%;width:${pw*100}%;transform:translate(-50%,-50%);border-radius:8px;outline:1px dashed #19e3c1`};
$('#pf2').onchange=e=>{const f=e.target.files[0];if(!f)return;if(pip)pip.remove();const v=f.type.startsWith('video');pip=document.createElement(v?'video':'img');pip.src=URL.createObjectURL(f);if(v){pip.muted=true;pip.loop=true;pip.playsInline=true}pl();PV.appendChild(pip);
 pip.onpointerdown=ev=>{pip.setPointerCapture(ev.pointerId);pip.d=1};pip.onpointermove=ev=>{if(!pip.d)return;const r=PV.getBoundingClientRect();px=Math.min(1,Math.max(0,(ev.clientX-r.left)/r.width));py=Math.min(1,Math.max(0,(ev.clientY-r.top)/r.height));pl()};pip.onpointerup=()=>pip.d=0};
$('#pz2').oninput=e=>{pw=e.target.value/100;pl()};$('#pd').onclick=()=>{if(pip){pip.remove();pip=null}};
V.addEventListener('play',()=>pip&&pip.play&&pip.play().catch(()=>{}));V.addEventListener('pause',()=>pip&&pip.pause&&pip.pause());
const od=window.drawSubtitle;window.drawSubtitle=function(ctx,cv){if(pip&&(pip.videoWidth||pip.naturalWidth)){const w=pw*cv.width,a=(pip.videoHeight||pip.naturalHeight)/(pip.videoWidth||pip.naturalWidth);ctx.drawImage(pip,px*cv.width-w/2,py*cv.height-w*a/2,w,w*a)}if(od)od.apply(this,arguments)};
// ---- Voiceover
tab('vcPanel','🎙','Voice',`<h3>Voiceover</h3><div class="trim-actions"><button id="rc" type="button">● Record</button></div><small id="rs">Records while the video plays. The voice is added as an audio track.</small>`);
let mr=null,ch=[];
$('#rc').onclick=async e=>{if(mr){mr.stop();return}try{const st=await navigator.mediaDevices.getUserMedia({audio:true});ch=[];mr=new MediaRecorder(st);mr.ondataavailable=x=>x.data.size&&ch.push(x.data);mr.onstop=()=>{st.getTracks().forEach(t=>t.stop());V.pause();const f=new File(ch,'voiceover_'+Date.now()+'.webm',{type:'audio/webm'}),dt=new DataTransfer();dt.items.add(f);const i=$('#extraAudioFiles');i.files=dt.files;i.dispatchEvent(new Event('change',{bubbles:true}));mr=null;e.target.textContent='● Record';$('#rs').textContent='Voiceover added to Audio tab tracks.'};mr.start();e.target.textContent='■ Stop';$('#rs').textContent='Recording…';V.play().catch(()=>{})}catch(x){$('#rs').textContent='Microphone not allowed. Allow it in phone settings.'}};
})();
