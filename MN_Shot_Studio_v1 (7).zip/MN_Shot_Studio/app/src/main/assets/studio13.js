(()=>{
const $=s=>document.querySelector(s),mk=h=>{const d=document.createElement('div');d.innerHTML=h.trim();return d.firstChild};
const sv=p=>`<svg viewBox="0 0 24 24">${p}</svg>`;
// ---- Back button -> Draft / Discard
const bh=$('#backHome');let bypass=0;
const dlg=mk(`<div id="bkDlg" hidden><div class="bx"><button class="dr" id="bkD" type="button">Draft ${sv('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>')}</button><button class="dc" id="bkX" type="button">Discard ${sv('<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>')}</button><p>Deleting the original video will damage the draft file.</p></div></div>`);document.body.append(dlg);
const goHome=()=>{bypass=1;bh.click();bypass=0;dlg.hidden=true};
bh.addEventListener('click',e=>{if(bypass)return;e.preventDefault();e.stopImmediatePropagation();dlg.hidden=false},true);
$('#bkD').onclick=()=>{try{$('#saveProjectTop').click()}catch(e){}setTimeout(goHome,150)};$('#bkX').onclick=goHome;dlg.onclick=e=>{if(e.target===dlg)dlg.hidden=true};
// ---- Expanded preview mode (fullscreen button)
const ed=$('#editorScreen');
ed.after(mk(`<div id="expPill"><button id="eu" type="button">${sv('<path d="M9 14L4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>')}</button><button id="er" type="button">${sv('<path d="M15 14l5-5-5-5"/><path d="M20 9H10a6 6 0 0 0 0 12h3"/>')}</button></div>`),mk(`<button id="expOut" type="button">${sv('<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>')}</button>`));
$('#cfs').onclick=()=>ed.classList.add('exp');$('#expOut').onclick=()=>ed.classList.remove('exp');
$('#eu').onclick=()=>$('#undoBtn').click();$('#er').onclick=()=>$('#redoBtn').click();
// ---- Settings screen
const hd=document.querySelector('header');
const sb=mk(`<button type="button" id="stBtn" aria-label="Settings" style="background:none;border:0;color:#fff;padding:8px">${sv('<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>')}</button>`);sb.querySelector('svg').style.cssText='width:24px;height:24px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round';if(hd)hd.append(sb);
const ic={vid:'<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 9l5 3-5 3z"/>',brush:'<path d="M4 20l4-1 11-11-3-3L5 16z"/>',pal:'<circle cx="12" cy="12" r="9"/><circle cx="8" cy="10" r="1"/><circle cx="12" cy="7" r="1"/><circle cx="16" cy="10" r="1"/>',help:'<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1 1-1 1.7M12 17h.01"/>',mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',cv:'<path d="M9 5l7 7-7 7"/>'};
const row=(i,t,s)=>mk(`<button class="it" type="button">${sv(ic[i])}<span class="tx">${t}${s?`<small>${s}</small>`:''}</span>${sv(ic.cv).replace('<svg','<svg class="cv"')}</button>`);
const scr=mk(`<div id="stScr" hidden><div class="hd"><button id="stBk" type="button">${sv('<path d="M15 5l-7 7 7 7"/>')}</button>Settings</div><h5>General</h5><div id="stG"></div><h5>Help</h5><div id="stH"></div></div>`);document.body.append(scr);
const vs=row('vid','Video Setting','Default export quality'),th=row('pal','Theme','Choose your accent colour'),cc=row('brush','Clear Cache','Free up temporary space'),qa=row('help','Q&amp;A','How to use the editor'),fb=row('mail','Send Feedback'),ab=row('info','About','MN Shot Studio v4.0');
scr.querySelector('#stG').append(vs,th,cc);scr.querySelector('#stH').append(qa,fb,ab);
sb.onclick=()=>scr.hidden=false;$('#stBk').onclick=()=>scr.hidden=true;
vs.onclick=()=>{const r=prompt('Default resolution: 480, 720, 1080',$('#exportResolution').value);if(r&&[...$('#exportResolution').options].some(o=>o.value===r)){$('#exportResolution').value=r;$('#exportResolution').dispatchEvent(new Event('change'))}};
const AC=[['#19e3c1','#0b3d36'],['#3b82f6','#10294f'],['#ff3d6e','#4a1424'],['#f5a524','#4a3208'],['#a78bfa','#2a2150']];
const setAc=i=>{const [a,b]=AC[i];document.documentElement.style.setProperty('--ac',a);document.documentElement.style.setProperty('--ac2',b);try{localStorage.setItem('mnAc',i)}catch(e){}};
th.onclick=()=>{const i=((+localStorage.getItem('mnAc')||0)+1)%AC.length;setAc(i)};try{const i=+localStorage.getItem('mnAc');if(i)setAc(i)}catch(e){}
cc.onclick=async()=>{if(!confirm('Clear temporary cache? Your saved drafts and fonts are kept.'))return;try{if(window.caches){for(const k of await caches.keys())await caches.delete(k)}sessionStorage.clear()}catch(e){}alert('Cache cleared.')};
qa.onclick=()=>alert('1. Tap Video and choose a clip.\n2. Use the toolbar to add text, stickers, filters, audio and effects.\n3. Drag the bars on the timeline to set when things appear.\n4. Tap Export to save your video.');
fb.onclick=()=>{location.href='mailto:?subject=MN%20Shot%20Studio%20feedback'};ab.onclick=()=>alert('MN Shot Studio v4.0');
})();
