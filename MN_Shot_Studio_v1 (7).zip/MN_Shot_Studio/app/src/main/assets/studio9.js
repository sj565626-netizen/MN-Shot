(()=>{
const $=s=>document.querySelector(s),mk=h=>{const d=document.createElement('div');d.innerHTML=h.trim();return d.firstChild};
const card=$('.create-card');if(!card)return;
const b=mk('<button type="button" class="create-option" id="homeBlank"><span class="option-icon"><svg viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="3"/></svg></span><b>Blank</b><small>Black canvas</small></button>');
card.append(b);
b.onclick=()=>{
 if(!window.MediaRecorder||!HTMLCanvasElement.prototype.captureStream){alert('Blank project is not supported on this phone.');return}
 b.querySelector('b').textContent='Making…';
 const c=document.createElement('canvas');c.width=720;c.height=1280;const x=c.getContext('2d');
 const fill=()=>{x.fillStyle='#000';x.fillRect(0,0,720,1280)};fill();
 const s=c.captureStream(30),r=new MediaRecorder(s,{mimeType:MediaRecorder.isTypeSupported('video/webm;codecs=vp8')?'video/webm;codecs=vp8':'video/webm'}),ch=[];
 const t=setInterval(fill,33);
 r.ondataavailable=e=>e.data.size&&ch.push(e.data);
 r.onstop=()=>{clearInterval(t);b.querySelector('b').textContent='Blank';const f=new File(ch,'blank.webm',{type:'video/webm'}),dt=new DataTransfer();dt.items.add(f);const i=$('#file');i.files=dt.files;i.dispatchEvent(new Event('change',{bubbles:true}))};
 r.start();setTimeout(()=>r.stop(),3000);
};
})();
