(()=>{
const $=s=>document.querySelector(s),mk=h=>{const d=document.createElement('div');d.innerHTML=h.trim();return d.firstChild};
const V=$('#video'),PV=$('.preview'),dock=$('.tool-dock');if(!PV||!$('#sa'))return;
const DEF=()=>({rich:1,f:'',s:56,c:'#ffffff',bc:'#000000',bw:3,sh:'',gl:'',lb:'',op:1,ls:0,lh:1.25,al:'center',up:0,b:1,i:0,u:0,rot:0,an:'',ot:'',lp:'',sp:.6});
const cur=()=>{const o=window.__selFn&&window.__selFn();return o&&o.rich?o:null};
function css(o){const e=o.el,s=e.style;e.textContent=o.t;s.fontFamily=o.f?`"${o.f}",Arial,sans-serif`:'Arial,sans-serif';s.fontSize=o.s+'px';s.fontWeight=o.b?'800':'400';s.fontStyle=o.i?'italic':'normal';s.textDecoration=o.u?'underline':'none';s.color=o.c;s.letterSpacing=o.ls+'px';s.lineHeight=o.lh;s.textAlign=o.al;s.textTransform=o.up?'uppercase':'none';s.whiteSpace='pre';
 s.webkitTextStroke=o.bw&&o.bc?`${o.bw}px ${o.bc}`:'0';s.paintOrder='stroke fill';
 const sh=[];if(o.sh)sh.push(`2px 3px 3px ${o.sh}`);if(o.gl)sh.push(`0 0 8px ${o.gl}`,`0 0 18px ${o.gl}`);s.textShadow=sh.join(',')||'none';
 s.background=o.lb||'transparent';s.padding=o.lb?'.15em .45em':'0';s.borderRadius=o.lb?'.3em':'0';s.textShadow=s.textShadow}
function create(){$('#st').value='Your text';$('#sa').click();const L=window.__stk,o=L[L.length-1];Object.assign(o,DEF());o.t='Your text';css(o);return o}
// ---- export drawing
window.__drawTxt=(ctx,cv,o)=>{const k=cv.width/(PV.clientWidth||1),px=o.s*k,lines=(o.up?o.t.toUpperCase():o.t).split('\n'),fam=o.f?`"${o.f}",Arial,Helvetica`:'Arial,Helvetica';
 ctx.font=`${o.i?'italic ':''}${o.b?'bold ':''}${px}px ${fam}`;if('letterSpacing' in ctx)ctx.letterSpacing=o.ls*k+'px';ctx.textBaseline='middle';ctx.textAlign=o.al;
 const lh=px*o.lh,H=lh*lines.length,w=Math.max(...lines.map(l=>ctx.measureText(l).width)),A=window.__anim?window.__anim(o):{rot:0};
 ctx.translate(o.x*cv.width,o.y*cv.height);ctx.rotate((o.rot||0)+(A.rot||0));ctx.globalAlpha*=o.op;
 if(o.lb){const p=px*.45,q=px*.15,r=px*.3;ctx.fillStyle=o.lb;ctx.beginPath();(ctx.roundRect||ctx.rect).call(ctx,-w/2-p,-H/2-q,w+p*2,H+q*2,r);ctx.fill()}
 const ax=o.al==='left'?-w/2:o.al==='right'?w/2:0;
 lines.forEach((l,i)=>{const y=-H/2+lh*(i+.5);ctx.save();
  if(o.gl){ctx.shadowColor=o.gl;ctx.shadowBlur=px*.45;ctx.fillStyle=o.gl;ctx.fillText(l,ax,y)}
  if(o.sh){ctx.shadowColor=o.sh;ctx.shadowOffsetX=px*.05;ctx.shadowOffsetY=px*.07;ctx.shadowBlur=px*.06}
  if(o.bw&&o.bc){ctx.lineWidth=o.bw*k;ctx.lineJoin='round';ctx.strokeStyle=o.bc;ctx.strokeText(l,ax,y)}
  ctx.fillStyle=o.c;ctx.fillText(l,ax,y);ctx.restore();
  if(o.u){const lw=ctx.measureText(l).width;ctx.fillStyle=o.c;ctx.fillRect((o.al==='left'?ax:o.al==='right'?ax-lw:-lw/2),y+px*.5,lw,Math.max(2,px/14))}})};
// ---- animations (IN / OUT / LOOP), speed per text
window.__anim=o=>{const t=V.currentTime||0,k=Math.min(1,Math.max(0,t-(o.t0||0))/(o.sp||.6)),e=1-Math.pow(1-k,3),r={a:1,s:1,dy:0,dx:0,rot:0};
 switch(o.an){case'fade':r.a=e;break;case'pop':r.a=e;r.s=.4+.6*e;break;case'slideup':r.a=e;r.dy=(1-e)*.12;break;case'slidedown':r.a=e;r.dy=-(1-e)*.12;break;case'slideleft':r.a=e;r.dx=(1-e)*.15;break;case'slideright':r.a=e;r.dx=-(1-e)*.15}
 switch(o.lp){case'bounce':r.dy-=Math.abs(Math.sin(t*5))*.03;break;case'pulse':r.s*=1+Math.sin(t*6)*.08;break;case'shake':r.dx+=Math.sin(t*40)*.008;break;case'spin':r.rot=t*2;break;case'heart':r.s*=1+Math.abs(Math.sin(t*4))*.12}
 if(o.ot&&V.duration){const q=Math.max(0,Math.min(1,((o.t1&&o.t1<1e8?o.t1:V.duration)-t)/.6));if(q<1){if(o.ot==='fade')r.a*=q;else if(o.ot==='shrink'){r.s*=q;r.a*=q}else{r.dy+=(1-q)*.12;r.a*=q}}}
 return r};
V.addEventListener('timeupdate',()=>(window.__stk||[]).forEach(o=>{if(!o.rich)return;const A=window.__anim(o);o.el.style.opacity=A.a*o.op;o.el.style.transform=`translate(-50%,-50%) translate(${A.dx*PV.clientWidth}px,${A.dy*PV.clientHeight}px) rotate(${(o.rot||0)+A.rot}rad) scale(${A.s})`}));
// ---- selection frame: delete / add / resize+rotate
const fr=mk('<div id="tbx2"><i class="a1">✕</i><i class="a2">A+</i><i class="a3">⤡</i></div>');PV.append(fr);
(function loop(){const o=cur();if(o&&o.el.style.display!=='none'){const a=o.el.getBoundingClientRect(),b=PV.getBoundingClientRect();fr.style.display='block';fr.style.left=a.left-b.left-6+'px';fr.style.top=a.top-b.top-6+'px';fr.style.width=a.width+12+'px';fr.style.height=a.height+12+'px'}else fr.style.display='none';requestAnimationFrame(loop)})();
fr.querySelector('.a1').onclick=()=>$('#sd').click();fr.querySelector('.a2').onclick=()=>{const o=create();open(o)};
const h=fr.querySelector('.a3');let g=null;
h.onpointerdown=e=>{const o=cur();if(!o)return;h.setPointerCapture(e.pointerId);const a=o.el.getBoundingClientRect(),cx=a.left+a.width/2,cy=a.top+a.height/2;g={o,cx,cy,d:Math.hypot(e.clientX-cx,e.clientY-cy)||1,an:Math.atan2(e.clientY-cy,e.clientX-cx),s:o.s,r:o.rot||0}};
h.onpointermove=e=>{if(!g)return;const o=g.o;o.s=Math.round(Math.min(200,Math.max(14,g.s*Math.hypot(e.clientX-g.cx,e.clientY-g.cy)/g.d)));o.rot=g.r+(Math.atan2(e.clientY-g.cy,e.clientX-g.cx)-g.an);css(o);V.dispatchEvent(new Event('timeupdate'))};h.onpointerup=()=>g=null;
// ---- editor UI
const ed=mk('<div id="txEd"><div class="txbar"><button id="tx0" type="button">✕</button><div class="tb"></div><button id="tx1" type="button">✓</button></div><div class="tc"></div></div>');document.body.append(ed);
const tb=ed.querySelector('.tb'),tc=ed.querySelector('.tc');let o=null,snap=null,isNew=false,tab='kb',st={a:'SPECIAL',c:'TEXT',n:'IN'};
const sv=p=>`<svg viewBox="0 0 24 24">${p}</svg>`;
const TABS=[['kb',sv('<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M7 10h.01M11 10h.01M15 10h.01M7 14h10"/>')],['st','<b style="font-size:19px;background:linear-gradient(135deg,#ff7a45,#7b61ff);-webkit-background-clip:text;color:transparent">A</b>'],['co','<span style="width:24px;height:24px;border-radius:50%;background:conic-gradient(red,yellow,lime,cyan,blue,magenta,red)"></span>'],['fo','Aa'],['al',sv('<path d="M4 6h16M4 12h10M4 18h14"/>')],['an',sv('<circle cx="9" cy="12" r="6"/><circle cx="15" cy="12" r="6" fill="#fff" fill-opacity=".25"/>')]];
tb.innerHTML=TABS.map(t=>`<button type="button" data-t="${t[0]}">${t[1]}</button>`).join('');
const PAL=['#ffffff','#000000','#ff3b30','#ff9500','#ffcc00','#34c759','#00c7be','#32ade6','#007aff','#5856d6','#af52de','#ff2d55','#a2845e','#8e8e93','#d1d1d6','#ffd1dc','#fff2a8','#b5ead7','#c7ceea','#ffdac1','#ff6f91','#845ec2','#00c9a7','#f9f871'];
const PRE={SPECIAL:[{c:'#fff',bw:0,bc:''},{c:'#fff',bc:'#000',bw:3},{c:'#ffd60a',bc:'#000',bw:3},{c:'#fff',gl:'#ff2d9b',bw:0,bc:''},{c:'#fff',gl:'#19e3c1',bw:0,bc:''},{c:'#ffd60a',sh:'#7a4b00',bw:0,bc:''},{c:'#ff3b30',bc:'#fff',bw:4},{c:'rgba(0,0,0,0)',bc:'#fff',bw:2}],
CAPTIONS:[{c:'#fff',lb:'rgba(0,0,0,.75)',bw:0,bc:''},{c:'#ffd60a',lb:'rgba(0,0,0,.75)',bw:0,bc:''},{c:'#fff',sh:'#000',bw:0,bc:'',lb:''},{c:'#111',lb:'#fff',bw:0,bc:''},{c:'#fff',lb:'#34c759',bw:0,bc:''}],
LABEL:[{c:'#fff',lb:'#ff2d55',bw:0,bc:''},{c:'#fff',lb:'#007aff',bw:0,bc:''},{c:'#111',lb:'#ffd60a',bw:0,bc:''},{c:'#fff',lb:'#5856d6',bw:0,bc:''},{c:'#111',lb:'#34c759',bw:0,bc:''},{c:'#fff',lb:'#000',bw:0,bc:''}],
TITLE:[{c:'#fff',bc:'#ff2d55',bw:5,sh:'#000'},{c:'#ffd60a',bc:'#7a4b00',bw:5},{c:'#fff',bc:'#007aff',bw:5,gl:'#007aff'},{c:'#ff3b30',bc:'#fff',bw:6,sh:'#000'}]};
const CK={TEXT:'c',BORDER:'bc',SHADOW:'sh',GLOW:'gl',LABEL:'lb'};
const AN={IN:['an',[['','None'],['fade','Fade'],['pop','Pop'],['slideup','Up'],['slidedown','Down'],['slideleft','Left'],['slideright','Right']]],OUT:['ot',[['','None'],['fade','Fade'],['shrink','Shrink'],['down','Down']]],LOOP:['lp',[['','None'],['bounce','Bounce'],['pulse','Pulse'],['shake','Shake'],['spin','Spin'],['heart','Heartbeat']]]};
const sub=(keys,key)=>`<div class="sub2">${keys.map(k=>`<span data-k="${k}" class="${st[key]===k?'on':''}">${k}</span>`).join('')}</div>`;
const apply=()=>{css(o);V.dispatchEvent(new Event('timeupdate'))};
function view(){tb.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.dataset.t===tab));tc.innerHTML='';
 if(tab==='kb'){const t=mk('<textarea placeholder="Type your text / اردو لکھیں"></textarea>');t.value=o.t==='Your text'&&isNew?'':o.t;t.oninput=()=>{o.t=t.value||' ';apply()};tc.append(t);setTimeout(()=>t.focus(),80)}
 if(tab==='st'){tc.innerHTML=sub(Object.keys(PRE),'a')+'<div class="grid"></div>';const gd=tc.querySelector('.grid');PRE[st.a].forEach(p=>{const t=mk('<div class="tile2">Aa</div>');const f=Object.assign(DEF(),p);const x=document.createElement('span');x.textContent='Aa';x.style.fontWeight='800';Object.assign(x,{});t.innerHTML='';t.append(x);const fake={el:x,t:'Aa',...f,s:26};css(fake);t.onclick=()=>{Object.assign(o,{bw:0,bc:'',sh:'',gl:'',lb:''},p);apply()};gd.append(t)});tc.querySelectorAll('.sub2 span').forEach(s=>s.onclick=()=>{st.a=s.dataset.k;view()})}
 if(tab==='co'){const keys=['TEXT','BORDER','SHADOW','GLOW','LABEL','OPACITY'];tc.innerHTML=sub(keys,'c');if(st.c==='OPACITY'){const r=mk(`<div class="row2"><span>Opacity</span><input type="range" min="10" max="100" value="${o.op*100}"></div>`);r.querySelector('input').oninput=e=>{o.op=e.target.value/100;apply()};tc.append(r)}else{const p=mk('<div class="pal"></div>'),k=CK[st.c];const none=mk('<i style="background:repeating-conic-gradient(#555 0 25%,#333 0 50%) 0/12px 12px"></i>');none.onclick=()=>{o[k]='';apply();view()};p.append(none);PAL.forEach(c=>{const i=mk(`<i style="background:${c}" class="${o[k]===c?'on':''}"></i>`);i.onclick=()=>{o[k]=c;if(k==='bc'&&!o.bw)o.bw=3;apply();view()};p.append(i)});tc.append(p)}tc.querySelectorAll('.sub2 span').forEach(s=>s.onclick=()=>{st.c=s.dataset.k;view()})}
 if(tab==='fo'){const w=mk('<div class="fl2"></div>');[...(document.querySelector('#fontSel')?.options||[])].forEach(op=>{const b=mk('<button type="button"></button>');b.textContent=op.value||'Default';if(op.value)b.style.fontFamily=`"${op.value}",sans-serif`;if((o.f||'')===op.value)b.className='on';b.onclick=()=>{o.f=op.value;apply();view()};w.append(b)});const im=mk('<button type="button" style="color:var(--ac)!important">⬇ Import font</button>');im.onclick=()=>$('#fontFile').click();w.append(im);tc.append(w)}
 if(tab==='al'){const R=(l,k,mn,mx,step)=>{const r=mk(`<div class="row2"><span>${l}</span><input type="range" min="${mn}" max="${mx}" step="${step}" value="${o[k]}"></div>`);r.querySelector('input').oninput=e=>{o[k]=+e.target.value;apply()};tc.append(r)};R('Size','s',14,200,1);R('Line spacing','lh',.8,2.4,.05);R('Letter spacing','ls',0,24,1);
  const op=mk('<div class="opt"></div>');[['b','B'],['i','I'],['u','U'],['up','AA']].forEach(([k,l])=>{const b=mk(`<button type="button" class="${o[k]?'on':''}">${l}</button>`);b.onclick=()=>{o[k]=o[k]?0:1;apply();view()};op.append(b)});['left','center','right'].forEach(a=>{const b=mk(`<button type="button" class="${o.al===a?'on':''}">${a}</button>`);b.onclick=()=>{o.al=a;apply();view()};op.append(b)});tc.append(op)}
 if(tab==='an'){tc.innerHTML=sub(['IN','OUT','LOOP'],'n');const [k,list]=AN[st.n],op=mk('<div class="opt"></div>');list.forEach(([v,l])=>{const b=mk(`<button type="button" class="${(o[k]||'')===v?'on':''}">${l}</button>`);b.onclick=()=>{o[k]=v;o.t0=o.t0;V.currentTime=0;V.play().catch(()=>{});view()};op.append(b)});tc.append(op);const r=mk(`<div class="row2"><span>Speed</span><input type="range" min="20" max="150" value="${o.sp*100}"></div>`);r.querySelector('input').oninput=e=>{o.sp=e.target.value/100};tc.append(r);tc.querySelectorAll('.sub2 span').forEach(s=>s.onclick=()=>{st.n=s.dataset.k;view()})}}
tb.onclick=e=>{const b=e.target.closest('button');if(b){tab=b.dataset.t;view()}};
function open(x){o=x;snap=JSON.stringify(Object.fromEntries(Object.entries(x).filter(([k])=>k!=='el')));document.body.classList.add('txm');tab='kb';view();window.__pick&&0}
function close(keep){document.body.classList.remove('txm');if(!keep&&o){if(isNew){$('#sd').click()}else{Object.assign(o,JSON.parse(snap));css(o)}}isNew=false;o=null}
$('#tx1').onclick=()=>close(true);$('#tx0').onclick=()=>close(false);
// Text tool button -> new text, or edit the selected one
const tbn=document.querySelector('[data-panel=textPanel]');
tbn.addEventListener('click',e=>{e.stopImmediatePropagation();e.preventDefault();let x=cur();isNew=!x;if(!x)x=create();open(x)},true);
})();
