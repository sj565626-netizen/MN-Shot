(()=>{
const $=s=>document.querySelector(s),mk=h=>{const d=document.createElement('div');d.innerHTML=h.trim();return d.firstChild},V=$('#video');
const C={Feature:[['Bright',{bri:1.12,sat:1.15,con:1.05}],['Pink',{hue:-15,sat:1.2,sep:.15,bri:1.05}],['Latte',{sep:.35,bri:1.05,con:.95,sat:1.1}],['Vintage',{sep:.45,con:.9,sat:.8}],['Moody',{con:1.2,bri:.9,sat:.85}],['Duo',{hue:60,sat:1.4,con:1.1}]],
Lunar:[['Moon',{gray:.6,bri:1.1,con:1.1,hue:200}],['Frost',{hue:190,sat:.8,bri:1.12}],['Night',{bri:.85,con:1.15,hue:215,sat:.9}],['Silver',{gray:.8,con:1.1,bri:1.05}]],
Skin:[['Soft',{bri:1.08,con:.92,sat:1.05,sep:.1}],['Peach',{sep:.2,hue:-8,bri:1.08,sat:1.15}],['Glow',{bri:1.15,con:.9,sat:1.1}],['Tan',{sep:.4,sat:1.3,con:1.05}]],
Jade:[['Jade',{hue:40,sat:1.3,con:1.05}],['Mint',{hue:55,sat:1.1,bri:1.1}],['Forest',{hue:35,sat:1.25,bri:.92,con:1.1}],['Sea',{hue:90,sat:1.2,bri:1.05}]],
Foodie:[['Tasty',{sat:1.5,con:1.1,bri:1.05,sep:.1}],['Warm',{sep:.3,sat:1.3,bri:1.05}],['Fresh',{sat:1.35,bri:1.1,hue:5}],['Rich',{con:1.2,sat:1.4,bri:.95}]],
Clear:[['Clear',{con:1.1,sat:1.1,bri:1.05}],['Crisp',{con:1.25,sat:1.05}],['Haze',{con:.85,bri:1.12,sat:.9}],['Pure',{sat:.9,bri:1.1,con:1.05}]],
Bright:[['Sunny',{bri:1.2,sat:1.2,sep:.15}],['Airy',{bri:1.25,con:.9,sat:.95}],['Pop',{bri:1.1,sat:1.5,con:1.1}],['Light',{bri:1.18,con:.95}]]};
const F={cat:'Feature',cur:null,s:1};
const fs=(f,s)=>`brightness(${1+((f.bri||1)-1)*s}) contrast(${1+((f.con||1)-1)*s}) saturate(${1+((f.sat||1)-1)*s}) sepia(${(f.sep||0)*s}) hue-rotate(${(f.hue||0)*s}deg) grayscale(${(f.gray||0)*s})`;
const ofs=window.filterString;window.filterString=()=>(ofs?ofs():'')+(F.cur&&(window.__fin?window.__fin():true)?' '+fs(F.cur,F.s):'');
window.__F=F;const upd=()=>window.updateFilter&&updateFilter();
const sec=$('#filterPanel section');
const sv=p=>`<svg viewBox="0 0 24 24">${p}</svg>`;
sec.append(mk('<div class="ft"><button class="on" data-t="f" type="button">Filter</button><button data-t="a" type="button">Adjust</button></div>'),mk('<div id="fv"><div class="chips"></div><div class="srow"><b id="fsv">100</b><input id="fsl" type="range" min="0" max="100" value="100"></div><div class="tiles"></div></div>'),mk('<div id="av" hidden><div class="srow"><b id="asv">0</b><input id="asl" type="range"></div><div class="adjrow"></div></div>'));
const chips=sec.querySelector('.chips'),tiles=sec.querySelector('.tiles');
const bg=async()=>{if(V.videoWidth&&V.readyState>1)try{return await createImageBitmap(V)}catch(e){}return null};
async function thumbs(){const bm=await bg();tiles.querySelectorAll('canvas').forEach(c=>{const x=c.getContext('2d'),f=c._f;x.filter='none';x.clearRect(0,0,208,208);if(bm){x.filter=f?fs(f,1):'none';x.drawImage(bm,0,0,208,208)}else{const g=x.createLinearGradient(0,0,208,208);g.addColorStop(0,'#e9a15b');g.addColorStop(.5,'#6fb08c');g.addColorStop(1,'#4a6fb5');x.filter=f?fs(f,1):'none';x.fillStyle=g;x.fillRect(0,0,208,208)}})}
function draw(){chips.innerHTML='';Object.keys(C).forEach(k=>{const b=mk(`<button type="button" class="${k===F.cat?'on':''}">${k}</button>`);b.onclick=()=>{F.cat=k;draw()};chips.append(b)});
 tiles.innerHTML='';const o=mk(`<button type="button" class="tile orig${F.cur?'':' on'}">${sv('<circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/>')}<span>ORIGINAL</span></button>`);o.onclick=()=>{F.cur=null;upd();draw()};tiles.append(o);
 C[F.cat].forEach(([n,f])=>{const t=mk(`<button type="button" class="tile${F.cur===f?' on':''}"><canvas width="208" height="208"></canvas><span>${n.toUpperCase()}</span></button>`);t.querySelector('canvas')._f=f;t.onclick=()=>{F.cur=f;F.n=n;F.s=$('#fsl').value/100;upd();draw()};tiles.append(t)});thumbs()}
$('#fsl').oninput=e=>{F.s=e.target.value/100;$('#fsv').textContent=e.target.value;upd()};
// Adjust tab
const el=s=>document.querySelector(s);
const AD=[['Lightness','#brightness','<circle cx="12" cy="12" r="4"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>'],['Contrast','#contrast','<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 1 0 18z" fill="currentColor"/>'],['Warmth','[data-e=warm]','<path d="M10 14V5a2 2 0 0 1 4 0v9a4 4 0 1 1-4 0z"/>'],['Saturation','#saturation','<path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z"/>'],['Hue','[data-e=hue]','<circle cx="12" cy="12" r="9"/><path d="M12 3v18M3 12h18"/>'],['Sepia','[data-e=sep]','<rect x="4" y="4" width="16" height="16" rx="3"/>'],['Blur','[data-e=blur]','<circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="8" stroke-dasharray="2 3"/>'],['Opacity','[data-e=fade]','<rect x="4" y="4" width="16" height="16"/><path d="M4 12h16M12 4v16"/>'],['Vignette','[data-e=vig]','<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/>'],['Grain','[data-e=grain]','<path d="M6 6h.01M12 8h.01M18 6h.01M8 13h.01M15 14h.01M6 18h.01M12 18h.01M18 18h.01"/>']];
const ar=sec.querySelector('.adjrow'),asl=$('#asl');let ae=null;
function pick(i){const [,s]=AD[i],e=el(s);if(!e)return;ae=e;asl.min=e.min;asl.max=e.max;asl.step=e.step||1;asl.value=e.value;asl.dataset.d=e.defaultValue;$('#asv').textContent=Math.round(e.value-e.defaultValue);ar.querySelectorAll('button').forEach((b,j)=>b.classList.toggle('on',j===i))}
AD.forEach(([n,s,p],i)=>{const b=mk(`<button type="button">${sv(p)}${n}</button>`);b.onclick=()=>pick(i);ar.append(b)});
asl.oninput=()=>{if(!ae)return;ae.value=asl.value;ae.dispatchEvent(new Event('input',{bubbles:true}));$('#asv').textContent=Math.round(asl.value-asl.dataset.d)};
pick(0);
sec.querySelectorAll('.ft button').forEach(b=>b.onclick=()=>{sec.querySelectorAll('.ft button').forEach(x=>x.classList.toggle('on',x===b));$('#fv').hidden=b.dataset.t!=='f';$('#av').hidden=b.dataset.t!=='a'});
$('[data-panel=filterPanel]').addEventListener('click',()=>setTimeout(draw,60));draw();
})();
