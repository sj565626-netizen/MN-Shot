(()=>{
const $=s=>document.querySelector(s),V=$('#video'),PV=$('.preview'),W=$('.editor-preview-wrap');
function fit(){if(!W||!PV)return;const r=window.__ratio||((V.videoWidth&&V.videoHeight)?V.videoWidth/V.videoHeight:9/16),aw=Math.max(50,W.clientWidth-20),ah=Math.max(50,W.clientHeight-10);let w=Math.min(aw,ah*r),h=w/r;PV.style.width=w+'px';PV.style.height=h+'px';PV.style.aspectRatio='auto';PV.style.margin='0 auto'}
['loadedmetadata','loadeddata'].forEach(e=>V.addEventListener(e,fit));window.addEventListener('resize',fit);
const rt=$('#rt');if(rt)rt.addEventListener('change',()=>setTimeout(fit,0));
new ResizeObserver(fit).observe(W);setInterval(fit,1200);fit();
})();
