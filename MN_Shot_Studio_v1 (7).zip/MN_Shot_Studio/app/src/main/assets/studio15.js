(()=>{
const $=s=>document.querySelector(s),PV=$('.preview'),ov=$('#overlay'),txt=$('#txt'),size=$('#size');
if(!PV||!ov||!txt)return;
const P=window.__txt={x:.5,y:.5};let sel=false;PV.style.position='relative';
const st=ov.style;st.position='absolute';st.bottom='auto';st.right='auto';st.maxWidth='none';st.whiteSpace='nowrap';st.transform='translate(-50%,-50%)';st.zIndex=6;st.pointerEvents='auto';st.touchAction='none';st.cursor='move';
const put=()=>{st.left=P.x*100+'%';st.top=P.y*100+'%'};put();
const fr=document.createElement('div');fr.id='tbx';fr.innerHTML='<i class="xx">✕</i><i class="rs"><svg viewBox="0 0 24 24"><path d="M5 19L19 5M13 5h6v6M11 19H5v-6"/></svg></i>';PV.append(fr);
const R=()=>PV.getBoundingClientRect();
(function loop(){const has=txt.value.trim().length>0;fr.style.display=has&&sel?'block':'none';if(has&&sel){const a=ov.getBoundingClientRect(),b=R();fr.style.left=a.left-b.left-8+'px';fr.style.top=a.top-b.top-8+'px';fr.style.width=a.width+16+'px';fr.style.height=a.height+16+'px'}requestAnimationFrame(loop)})();
let mode=0,s0;
ov.addEventListener('pointerdown',e=>{if(!txt.value.trim())return;sel=true;mode='m';ov.setPointerCapture(e.pointerId);e.preventDefault()});
ov.addEventListener('pointermove',e=>{if(mode!=='m')return;const b=R();const mx=Math.min(.5,(ov.offsetWidth/2+16)/b.width),my=Math.min(.5,(ov.offsetHeight/2+16)/b.height);P.x=Math.min(1-mx,Math.max(mx,(e.clientX-b.left)/b.width));P.y=Math.min(1-my,Math.max(my,(e.clientY-b.top)/b.height));put()});
ov.addEventListener('pointerup',()=>mode=0);
const rs=fr.querySelector('.rs'),xx=fr.querySelector('.xx');
rs.addEventListener('pointerdown',e=>{mode='r';rs.setPointerCapture(e.pointerId);const a=ov.getBoundingClientRect(),cx=a.left+a.width/2,cy=a.top+a.height/2;s0={cx,cy,d:Math.hypot(e.clientX-cx,e.clientY-cy)||1,v:+size.value};e.stopPropagation()});
rs.addEventListener('pointermove',e=>{if(mode!=='r')return;const d=Math.hypot(e.clientX-s0.cx,e.clientY-s0.cy);size.value=Math.round(Math.min(+size.max||200,Math.max(+size.min||10,s0.v*d/s0.d)));size.dispatchEvent(new Event('input',{bubbles:true}))});
rs.addEventListener('pointerup',()=>mode=0);
xx.addEventListener('click',()=>{txt.value='';txt.dispatchEvent(new Event('input',{bubbles:true}));sel=false});
PV.addEventListener('pointerdown',e=>{if(e.target!==ov&&!fr.contains(e.target))sel=false});
txt.addEventListener('input',()=>{if(txt.value.trim())sel=true});
// simpler Text panel: position is now by finger
const pl=$('#pos')&&$('#pos').closest('label');if(pl)pl.style.display='none';
const tp=document.querySelector('#textPanel section');if(tp){const h=document.createElement('small');h.textContent='Drag the text on the video to move it. Use the corner handle to resize.';tp.append(h)}
const tb=document.querySelector('[data-panel=textPanel]');if(tb)tb.addEventListener('click',()=>setTimeout(()=>{if(!txt.value.trim())txt.focus()},120));
// readable colours on the home screen
const lum=c=>{const m=c.match(/\d+/g);return m?(.3*m[0]+.59*m[1]+.11*m[2])/255:1};
function contrast(){document.querySelectorAll('#homeScreen *,header *').forEach(e=>{if(e.closest('.video-option')||e.closest('svg'))return;if(lum(getComputedStyle(e).color)<.4&&e.childNodes.length&&[...e.childNodes].some(n=>n.nodeType===3&&n.nodeValue.trim()))e.style.color='#dfe3ea'})}
contrast();setTimeout(contrast,600);
})();
