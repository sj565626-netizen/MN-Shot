(()=>{
const P={
'↶':'<path d="M9 14L4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>','↷':'<path d="M15 14l5-5-5-5"/><path d="M20 9H10a6 6 0 0 0 0 12h3"/>',
'⛶':'<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>','▶':'<path d="M7 4l13 8-13 8z"/>','❚❚':'<path d="M7 4h4v16H7zM13 4h4v16h-4z"/>',
'‹':'<path d="M15 5l-7 7 7 7"/>','＋':'<path d="M12 5v14M5 12h14"/>','−':'<path d="M5 12h14"/>','✓':'<path d="M5 12l5 5 9-10"/>',
'⬇':'<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>','✎':'<path d="M4 20l4-1 11-11-3-3L5 16z"/>','●':'<circle cx="12" cy="12" r="6" fill="currentColor"/>',
'■':'<rect x="6" y="6" width="12" height="12" rx="1.5"/>','⏹':'<rect x="6" y="6" width="12" height="12" rx="1.5"/>','⇥':'<path d="M4 5h6v14H4zM14 8l6 4-6 4z"/>',
'♪':'<path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/>','✸':'<path d="M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z"/>',
'📷':'<rect x="3" y="7" width="18" height="13" rx="3"/><circle cx="12" cy="13" r="3.5"/><path d="M9 7l1.5-3h3L15 7"/>','🗑':'<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
'⟳':'<path d="M20 12a8 8 0 1 1-3-6.2M20 4v5h-5"/>','⇋':'<path d="M12 3v18M8 7L3 12l5 5zM16 7l5 5-5 5z"/>','⏪':'<path d="M11 6L3 12l8 6zM21 6l-8 6 8 6z"/>','⏩':'<path d="M13 6l8 6-8 6zM3 6l8 6-8 6z"/>',
'⚙':'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>','✂':'<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M8 8l12 10M8 16L20 6"/>','🎙':'<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>'};
const keys=Object.keys(P).sort((a,b)=>b.length-a.length),rx=new RegExp('^\\s*('+keys.join('|')+')\\s*'),svg=k=>`<span class="ic"><svg viewBox="0 0 24 24" aria-hidden="true">${P[k]}</svg></span>`;
window.__svgIcon=svg;
function conv(root){root.querySelectorAll('button,.draft-empty-icon').forEach(b=>{[...b.childNodes].forEach(n=>{if(n.nodeType!==3)return;const m=rx.exec(n.nodeValue);if(!m)return;const s=document.createElement('span');s.innerHTML=svg(m[1]);b.insertBefore(s.firstChild,n);const rest=n.nodeValue.slice(m[0].length);if(rest)n.nodeValue=rest;else n.remove()})})}
// extra clean-ups
document.querySelectorAll('button').forEach(b=>{if(/PRO/.test(b.textContent)&&b.closest('header'))b.remove();if(/Export\s*↗/.test(b.textContent))b.textContent='Export'});
const di=document.querySelector('.draft-empty-icon');if(di)di.innerHTML='<svg viewBox="0 0 24 24"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>';
const h=document.querySelector('.hero-copy');if(h){h.innerHTML='<p class="eyebrow">VIDEO · PHOTO · COLLAGE</p><h1>MN Shot Studio</h1><p class="hero-sub">Edit videos, photos and collages in one place.</p>'}
const sh=document.querySelector('.section-heading');if(sh)sh.textContent='CREATE';
const pp=document.querySelector('#playPreview'),V=document.querySelector('#video');
const setPlay=on=>{if(!pp)return;pp.innerHTML=svg(on?'❚❚':'▶')};
if(V){V.addEventListener('play',()=>setPlay(1));V.addEventListener('pause',()=>setPlay(0));V.addEventListener('ended',()=>setPlay(0))}
conv(document.body);setPlay(V&&!V.paused);
let tm=0;new MutationObserver(()=>{clearTimeout(tm);tm=setTimeout(()=>conv(document.body),60)}).observe(document.body,{childList:true,subtree:true,characterData:true});
})();
