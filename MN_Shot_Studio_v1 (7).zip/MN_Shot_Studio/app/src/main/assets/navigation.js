(()=>{
 const home=document.getElementById('homeScreen'),editor=document.getElementById('editorScreen');
 const file=document.getElementById('file');
 const openEditor=()=>{home.hidden=true;editor.hidden=false;window.scrollTo(0,0)};
 const openHome=()=>{editor.hidden=true;home.hidden=false;window.scrollTo(0,0)};
 ['homeNewVideo','homeNewVideo2'].forEach(id=>document.getElementById(id)?.addEventListener('click',()=>file.click()));
 document.getElementById('backHome')?.addEventListener('click',openHome);
 file?.addEventListener('change',()=>{if(file.files&&file.files.length){openEditor();document.getElementById('editorProjectName').textContent=file.files[0].name;}});
 document.getElementById('saveProjectTop')?.addEventListener('click',()=>document.getElementById('saveProject').click());
 document.getElementById('exportTop')?.addEventListener('click',()=>{document.getElementById('exportAll').scrollIntoView({behavior:'smooth',block:'center'});});
 document.getElementById('playPreview')?.addEventListener('click',()=>{const v=document.getElementById('video');if(!v.src)return;if(v.paused)v.play().catch(()=>{});else v.pause();});
 const v=document.getElementById('video');const fmt=t=>{if(!Number.isFinite(t))return '00:00';return String(Math.floor(t/60)).padStart(2,'0')+':'+String(Math.floor(t%60)).padStart(2,'0')};
 v?.addEventListener('timeupdate',()=>{document.getElementById('currentTimeLabel').textContent=fmt(v.currentTime);document.getElementById('durationLabel').textContent=fmt(v.duration)});
 document.querySelectorAll('.tool-dock button').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.tool-dock button').forEach(b=>b.classList.remove('active'));btn.classList.add('active');document.querySelectorAll('.tool-panel').forEach(p=>p.hidden=true);const target=document.getElementById(btn.dataset.panel);if(target){target.hidden=false;target.scrollIntoView({behavior:'smooth',block:'nearest'});}}));
 document.getElementById('splitShortcut')?.addEventListener('click',()=>document.getElementById('splitClip').click());
 document.getElementById('duplicateShortcut')?.addEventListener('click',()=>document.getElementById('duplicateClip').click());
 document.getElementById('settingsBtn')?.addEventListener('click',()=>{if(editor.hidden){openEditor();document.getElementById('projectPanel').scrollIntoView({behavior:'smooth'});}else{document.getElementById('projectPanel').hidden=false;document.getElementById('projectPanel').scrollIntoView({behavior:'smooth'});}});
})();