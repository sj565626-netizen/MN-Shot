(()=>{
const $=s=>document.querySelector(s),mk=h=>{const d=document.createElement('div');d.innerHTML=h.trim();return d.firstChild};
const V=$('#video'),ed=$('#editorScreen'),dock=$('.tool-dock');
const sv=p=>`<svg viewBox="0 0 24 24" aria-hidden="true">${p}</svg>`;
// ---- control row: undo, redo, play, fullscreen
const ctl=mk('<div class="ctl"><div><button id="cu" type="button">↶</button><button id="cr" type="button">↷</button></div><span id="cpl"></span><button id="cfs" type="button" aria-label="Fullscreen">⛶</button></div>');
ctl.querySelector('#cpl').replaceWith($('#playPreview'));$('.editor-preview-wrap').after(ctl);
const sync=()=>{ctl.querySelector('#cu').disabled=$('#undoBtn').disabled;ctl.querySelector('#cr').disabled=$('#redoBtn').disabled};
ctl.querySelector('#cu').onclick=()=>$('#undoBtn').click();ctl.querySelector('#cr').onclick=()=>$('#redoBtn').click();
setInterval(sync,400);$('#cfs').onclick=()=>{const p=$('.preview');(p.requestFullscreen||p.webkitRequestFullscreen||(()=>{})).call(p)};
const pp=$('#playPreview');new MutationObserver(()=>{});V.addEventListener('play',()=>pp.textContent='❚❚');V.addEventListener('pause',()=>pp.textContent='▶');
// ---- toolbar: one flat row in InShot order
const act=(id,lb,ic,fn)=>{const b=mk(`<button type="button" data-act="${id}">${sv(ic)}${lb}</button>`);b.onclick=fn;return b};
const ic={split:'<path d="M12 3v18M5 7h4v10H5zM15 7h4v10h-4z"/>',del:'<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',dup:'<rect x="3" y="5" width="8" height="14" rx="2"/><rect x="13" y="5" width="8" height="14" rx="2"/>',rot:'<path d="M20 12a8 8 0 1 1-3-6.2M20 4v5h-5"/>',cap:'<rect x="4" y="5" width="16" height="14" rx="3"/><circle cx="12" cy="12" r="3"/>',rev:'<path d="M20 5v14L9 12zM5 5v14"/>',mute:'<path d="M4 9v6h4l5 4V5L8 9zM17 9l4 6M21 9l-4 6"/>'};
const L={Canvas:'fmtPanel',Audio:'audioPanel',Sticker:'stkPanel',Text:'textPanel',Effect:'fxPanel',Transition:'effectPanel',Filter:'filterPanel',PIP:'pipPanel',Trim:'canvasPanel',SPLIT:0,DELETE:0,Speed:'speedPanel',Animation:'anPanel',Crop:'magPanel',ROTATE:0,DUP:0,CAPTURE:0,REVERSE:0,Adjust:'adjPanel',Fonts:'fontPanel',Subtitles:'subtitlePanel',Voice:'vcPanel'};
const byP={};dock.querySelectorAll('button[data-panel]').forEach(b=>byP[b.dataset.panel]=b);
const A={SPLIT:()=>act('split','Split',ic.split,()=>$('#splitClip').click()),DELETE:()=>act('del','Delete',ic.del,()=>{if(typeof selectedClip!=='undefined'&&selectedClip>=0&&typeof removeClip==='function')removeClip(selectedClip)}),ROTATE:()=>act('rot','Rotate',ic.rot,()=>$('#vr').click()),DUP:()=>act('dup','Duplicate',ic.dup,()=>$('#duplicateClip').click()),CAPTURE:()=>act('cap','Capture',ic.cap,()=>$('#vs').click()),REVERSE:()=>act('rev','Reverse',ic.rev,()=>$('#mr').click())};
Object.entries(L).forEach(([lb,id])=>{if(id){const b=byP[id];if(b){b.lastChild.nodeType===3?b.lastChild.textContent=lb:0;dock.appendChild(b)}}else dock.appendChild(A[lb]())});
dock.scrollLeft=0;
// ---- timeline: red + , mute clip, time labels
const tl=$('.timeline');
const add=mk('<button id="addClipBtn" type="button" aria-label="Add clip">+</button>'),mute=mk(`<button id="muteClip" type="button">${sv(ic.mute).replace('<svg','<svg style="width:22px;height:22px;stroke:#aaa;fill:none;stroke-width:1.8"')}Mute Clip</button>`);
tl.prepend(mute);tl.prepend(add);
add.onclick=()=>$('#multiFiles').click();mute.onclick=()=>$('#vm').click();
const tc=mk('<div id="tcRow"></div>');tc.append($('#currentTimeLabel'),' / ',$('#durationLabel'));$('.timeline-shell').append(tc);
// ---- export sheet
const ex=mk(`<div id="expSheet" hidden><div class="bx"><h4>EXPORT</h4><div class="r" id="xr"></div><div class="r" id="xf"></div><div class="r"><span style="color:#bbb">Format</span><span>MP4</span></div><div class="r"><span style="color:#bbb">Estimated size</span><b id="xs">–</b></div><button class="go" id="xg" type="button">EXPORT</button><div id="xp"></div><small>MN SHOT STUDIO · v4.0 NEW</small></div></div>`);document.body.append(ex);
$('#xr').append($('#exportResolution').closest('label'));$('#xf').append($('#exportFps').closest('label'));
$('#xp').append($('.export-progress'),$('#status'));
const est=()=>{const d=V.duration||0,r=$('#exportResolution').value,m=r==='1080'?8:r==='720'?5:10,f=$('#exportFps').value/30;$('#xs').textContent=d?(d*m*f/8).toFixed(1)+' MB':'–'};
['#exportResolution','#exportFps'].forEach(s=>$(s).addEventListener('change',est));
const eb=$('#exportTop'),nb=eb.cloneNode(true);eb.replaceWith(nb);nb.textContent='Export';nb.onclick=()=>{est();ex.hidden=false};
ex.onclick=e=>{if(e.target===ex)ex.hidden=true};$('#xg').onclick=()=>{if(typeof timelineClips!=='undefined'&&timelineClips.length)$('#exportAll').click();else $('#export').click()};V.removeAttribute('controls');V.controls=false;V.addEventListener('click',()=>V.paused?V.play():V.pause());
})();
