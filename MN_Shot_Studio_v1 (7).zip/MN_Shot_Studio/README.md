# MN Shot Studio v3.2

MN Shot Studio is an Android WebView-based video editor prototype. This version refreshes the app branding and UI with a custom MN Shot mark, warm gradient home screen, project-start cards, dark editing workspace, preview, timeline, and grouped editing tools.

## Current capabilities
- Import and preview video clips
- Multi-clip timeline, reorder, split and duplicate
- Trim controls and clip transitions
- Audio/music tracks and volume/fade settings
- Text overlay, filters, SRT subtitles
- Project save/open and local draft recovery
- WebM browser export and Android Media3 MP4 conversion pipeline for combined timeline export

Photo editing and collage are displayed as coming soon and are not implemented. The visual layout is inspired by the supplied reference screenshots, but MN Shot uses its own branding and assets.

## Build
Open this project in Android Studio or use the repository GitHub Actions workflow. A successful CI build and real-device test are still required before treating the APK as verified.
