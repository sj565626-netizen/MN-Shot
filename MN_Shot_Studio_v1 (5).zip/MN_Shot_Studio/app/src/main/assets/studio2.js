(()=>{
const $=s=>document.querySelector(s),mk=h=>{const d=document.createElement('div');d.innerHTML=h.trim();return d.firstChild};
const V=$('#video'),PV=$('.preview'),dock=$('.tool-dock'),pan=$('.editor-panels');
const tab=(id,ic,lb,body)=>{dock.appendChild(mk(`<button type="button" data-panel="${id}"><span>${ic}</span>${lb}</button>`));pan.appendChild(mk(`<div id="${id}" class="tool-panel" hidden><section>${body}</section></div>`))};
// ---- Speed / volume / rotate / flip / snapshot
tab('speedPanel','⏩','Speed',`<h3>Speed &amp; video</h3><label>Speed <b id="spv">1x</b><input id="sp" type="range" min="0.25" max="4" step="0.25" value="1"></label><label>Video volume <input id="vv" type="range" min="0" max="1" step="0.05" value="1"></label><div class="trim-actions"><button id="vm" type="button">Mute</button><button id="vr" type="button">⟳ Rotate</button><button id="vf" type="button">⇋ Flip</button><button id="vs" type="button">📷 Save frame</button></div><small>Speed, volume, rotate and flip show in preview and playback. Export of rotate/flip is not added yet.</small>`);
let rot=0,fl=1;const tr=()=>{window.__rf=[rot,fl];document.dispatchEvent(new Event('mnxf'))};
const setRate=()=>{const r=Number($('#sp').value);V.defaultPlaybackRate=r;V.playbackRate=r;$('#spv').textContent=r+'x'};
$('#sp').oninput=setRate;V.addEventListener('loadedmetadata',setRate);V.addEventListener('play',setRate);
$('#vv').oninput=e=>V.volume=Number(e.target.value);
$('#vm').onclick=e=>{V.muted=!V.muted;e.target.textContent=V.muted?'Unmute':'Mute'};
$('#vr').onclick=()=>{rot=(rot+1)%4;tr()};$('#vf').onclick=()=>{fl*=-1;tr()};
$('#vs').onclick=()=>{if(!V.videoWidth)return;const c=document.createElement('canvas');c.width=V.videoWidth;c.height=V.videoHeight;c.getContext('2d').drawImage(V,0,0);c.toBlob(b=>{const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='MN_frame.png';a.click()})};
// ---- Canvas ratio + background
tab('fmtPanel','▭','Format',`<h3>Canvas format</h3><label>Ratio <select id="rt"><option value="">Original</option><option value="9/16">9:16 TikTok / Reels</option><option value="1/1">1:1 Instagram</option><option value="4/5">4:5 Portrait</option><option value="16/9">16:9 YouTube</option><option value="3/4">3:4</option></select></label><label>Background <input id="bg" type="color" value="#000000"></label><small>Ratio and background apply to the preview and the exported video.</small>`);
$('#rt').onchange=e=>{window.__ratio=e.target.value?eval(e.target.value):0;PV.style.aspectRatio=e.target.value||'';PV.style.maxHeight=e.target.value?'60vh':'';PV.style.margin='0 auto'};
$('#bg').oninput=e=>PV.style.background=e.target.value;
// ---- Stickers + text stickers (drag, resize, exported)
const EM='😀😂😍😎🥳🔥💯❤️⭐✨🎉👍👑🌹🎵💥👀🙏☀️🌙'.match(/\p{Extended_Pictographic}(\uFE0F)?/gu);
tab('stkPanel','☺','Stickers',`<h3>Stickers &amp; text</h3><div id="eg" style="display:flex;flex-wrap:wrap;gap:6px;font-size:26px"></div><label>Text sticker <input id="st" placeholder="Type text / اردو لکھیں"></label><div class="trim-actions"><button id="sa" type="button">＋ Add text</button><button id="sd" type="button">🗑 Delete selected</button></div><label>Size <input id="ss" type="range" min="16" max="160" value="56"></label><label>Color <input id="sc" type="color" value="#ffffff"></label><small>Drag stickers on the preview. They are included in export. Text uses your chosen font.</small>`);
const L=[];let sel=null;PV.style.position='relative';
EM.forEach(e=>{const b=mk(`<button type="button" style="background:none;border:0;font-size:26px">${e}</button>`);b.onclick=()=>add(e);$('#eg').appendChild(b)});
function add(t,c){const o={t,x:.5,y:.5,s:Number($('#ss').value),c:c||'#fff'};o.el=mk(`<div style="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);touch-action:none;white-space:nowrap;z-index:6;font-weight:700;text-shadow:0 1px 4px #000"></div>`);o.el.textContent=t;o.el.style.fontSize=o.s+'px';o.el.style.color=o.c;if(window.__mnFont)o.el.style.fontFamily=window.__mnFont;o.el.dir='auto';PV.appendChild(o.el);L.push(o);pick(o);
 o.el.onpointerdown=e=>{pick(o);o.el.setPointerCapture(e.pointerId);o.drag=1};
 o.el.onpointermove=e=>{if(!o.drag)return;const r=PV.getBoundingClientRect();o.x=Math.min(1,Math.max(0,(e.clientX-r.left)/r.width));o.y=Math.min(1,Math.max(0,(e.clientY-r.top)/r.height));o.el.style.left=o.x*100+'%';o.el.style.top=o.y*100+'%'};
 o.el.onpointerup=()=>o.drag=0}
function pick(o){sel=o;L.forEach(k=>k.el.style.outline=k===o?'1px dashed #19e3c1':'none');$('#ss').value=o.s;$('#sc').value=o.c.length==7?o.c:'#ffffff'}
$('#sa').onclick=()=>{const t=$('#st').value.trim();if(t){add(t,$('#sc').value);$('#st').value=''}};
$('#ss').oninput=e=>{if(sel){sel.s=Number(e.target.value);sel.el.style.fontSize=sel.s+'px'}};
$('#sc').oninput=e=>{if(sel){sel.c=e.target.value;sel.el.style.color=sel.c}};
window.__stk=L;window.__selFn=()=>sel;
$('#sd').onclick=()=>{if(sel){sel.el.remove();L.splice(L.indexOf(sel),1);sel=null}};
const od=window.drawSubtitle;window.drawSubtitle=function(ctx,cv,tm){if(od)od.apply(this,arguments);const W=PV.clientWidth||1;L.forEach(o=>{if(tm!==undefined&&window.__vis&&!window.__vis(o,tm))return;ctx.save();const A=window.__anim?window.__anim(o):{a:1,s:1,dy:0};ctx.globalAlpha=A.a;ctx.translate(o.x*cv.width,(o.y+A.dy)*cv.height);ctx.scale(A.s,A.s);ctx.translate(-o.x*cv.width,-o.y*cv.height);ctx.font=`bold ${o.s*cv.width/W}px sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.lineWidth=o.s*cv.width/W/14;ctx.strokeStyle='#000';ctx.fillStyle=o.c;ctx.strokeText(o.t,o.x*cv.width,o.y*cv.height);ctx.fillText(o.t,o.x*cv.width,o.y*cv.height);ctx.restore()})};
})();
